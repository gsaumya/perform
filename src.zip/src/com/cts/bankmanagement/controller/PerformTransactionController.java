package com.cts.bankmanagement.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.cts.bankmanagement.exception.BankManagementException;
import com.cts.bankmanagement.service.PerformTransactionService;
import com.cts.bankmanagement.vo.TransactionVO;

@Controller
public class PerformTransactionController {

	@Autowired
	private PerformTransactionService transactionService;
	
	@Autowired
	private Validator validator;
	
	private static final Logger LOG = Logger.getLogger(PerformTransactionController.class);

	@ResponseBody
	@RequestMapping(value = "performtransaction", method = RequestMethod.POST)
	ModelAndView initiateTransaction(@RequestParam(value = "accountNumber") Long accountNumber,
			@RequestParam(value = "transactionType") String transactionType,
			@RequestParam(value = "transactionAmount") Double transactionAmount,
			@RequestParam(value = "description") String description) throws BankManagementException {

		LOG.info("In PerformTransactionController");

		TransactionVO transactionVO = new TransactionVO(accountNumber,  transactionType, transactionAmount, description);
		Set<ConstraintViolation<TransactionVO>> validationErrors = validator.validate(transactionVO);
		if (!validationErrors.isEmpty()) {
			Map<String, String> errors = getVallidationErrors(validationErrors);
			LOG.warn("Validation errors :" + errors.toString());
			return new ModelAndView("Transaction/performTransaction", "errors", errors);
		}
		try {
			Double tid = transactionService.updateTransactionDetail(transactionVO);
			transactionVO.setTransactionAmount(tid);
			return new ModelAndView("transaction", "user", tid);
		} catch (BankManagementException ex) {
			LOG.warn("Validation errors :" + ex);
			return new ModelAndView("Transaction/performTransaction", ex.getErrorkey(), ex.getMessage());
		}

	}

	private Map<String, String> getVallidationErrors(Set<ConstraintViolation<TransactionVO>> validationErrors) {
		Map<String, String> errors = new HashMap<String, String>(validationErrors.size());
		for (ConstraintViolation<TransactionVO> constraintViolation : validationErrors) {
			errors.put(constraintViolation.getPropertyPath().toString(), constraintViolation.getMessage());
		}

		return errors;

	}

	@RequestMapping(value = "/performtransactionForm")
	public String performTransactionForm() {
		return "Transaction/performTransaction";
	}
}
