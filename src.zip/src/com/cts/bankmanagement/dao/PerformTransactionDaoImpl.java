package com.cts.bankmanagement.dao;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.bankmanagement.entity.TransactionDetail;
import com.cts.bankmanagement.vo.TransactionVO;


@Repository("transactionDao")
public class PerformTransactionDaoImpl implements PerformTransactionDao {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public Double updateTransactionDetail(TransactionVO transactionVO) {

		TransactionDetail ud = getTransactionDetail(transactionVO);
		Long transactionId = (Long) sessionFactory.getCurrentSession().save(ud);
		Double d = transactionId.doubleValue();
		return d;
	}

	@Override
	public Long countTransactionDetail() {
		Query query = sessionFactory.getCurrentSession().createQuery("Select count(*) from TransactionDetail");
		Long count = (Long) query.uniqueResult();
		return count;
	}

	private TransactionDetail getTransactionDetail(TransactionVO transactionVO) {
	if(transactionVO !=null){
		return new TransactionDetail(transactionVO.getTransactionId(), transactionVO.getAccountNumber(),
				transactionVO.getTransactionType(), transactionVO.getTransactionAmount(),
				transactionVO.getDescription(), null);
	}
	return null;
}

	}


