package com.cts.bankmanagement.dao;

import java.util.List;

import com.cts.bankmanagement.vo.TransactionVO;

public interface ViewTransactionDao {

	TransactionVO getTransactionDao(Long transactionId);

	List<TransactionVO> getTransactionDetails(Long accountNumber, Long transactionId);

	List<TransactionVO> getTransactionDetails(Long accountNumber);
}
