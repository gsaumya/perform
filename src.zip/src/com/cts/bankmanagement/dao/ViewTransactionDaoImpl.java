package com.cts.bankmanagement.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.cts.bankmanagement.entity.TransactionDetail;
import com.cts.bankmanagement.vo.TransactionVO;
import com.cts.bankmanagement.vo.UserVO;

@Repository("viewDao")
public class ViewTransactionDaoImpl implements ViewTransactionDao {

	@Autowired
	private SessionFactory sessionFactory;

	private List<TransactionVO> getTransactionsVO(List<TransactionDetail> transactions) {
		if (CollectionUtils.isEmpty(transactions)) {
			return Collections.emptyList();
		}

		List<TransactionVO> usersVO = new ArrayList<TransactionVO>(transactions.size());
		for (TransactionDetail user : transactions) {
			usersVO.add(getTransactionsVO(user));
		}
		return usersVO;
	}

	private TransactionVO getTransactionsVO(TransactionDetail transactionDetails) {
		if (transactionDetails != null) {
			UserVO userVO = UserDAOImpl.getUserVO(transactionDetails.getUserDetails());
			return new TransactionVO(transactionDetails.getTransactionId(), userVO,
					transactionDetails.getTransactionAmount(), transactionDetails.getTransactionType(),
					transactionDetails.getDescription());
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public TransactionVO getTransactionDao(Long transactionId) {
		Query query = sessionFactory.getCurrentSession()
				.createQuery("from TransactionDetail where " + "transactionId = :transactionId");
		query.setParameter("transactionId", transactionId);
		List<TransactionDetail> list = query.list();
		if (CollectionUtils.isEmpty(list)) {
			return null;
		}
		return getTransactionsVO(list.get(0));
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TransactionVO> getTransactionDetails(Long accountNumber) {
		Query query = sessionFactory.getCurrentSession()
				.createQuery("from TransactionDetail t inner join fetch t.userDetails as u  where u.accountNumber "
						+ " = :accountNumber");
		query.setParameter("accountNumber", accountNumber);
		return getTransactionsVO((List<TransactionDetail>) query.list());
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TransactionVO> getTransactionDetails(Long accountNumber, Long transactionId) {
		Query query = sessionFactory.getCurrentSession()
				.createQuery("from TransactionDetail t inner join fetch t.userDetails as u where u.accountNumber "
						+ "= :acNo and t.transactionId = :transactionId");
		query.setParameter("acNo", accountNumber);
		query.setParameter("transactionId", transactionId);
		return getTransactionsVO((List<TransactionDetail>) query.list());
	}
	
}
