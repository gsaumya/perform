package com.cts.bankmanagement.exception;

public class BankManagementException extends Exception {
	static final long serialVersionUID = -3387516993124229978L;

	private String errorkey;

	public String getErrorkey() {
		return errorkey;
	}

	public void setErrorkey(String errorkey) {
		this.errorkey = errorkey;
	}

	public BankManagementException(String errorkey, String message, Throwable cause) {
		super(message, cause);
		this.errorkey = errorkey;
	}

	public BankManagementException(String errorkey, String message) {
		super(message);
		this.errorkey = errorkey;
	}

	public BankManagementException(Throwable cause) {
		super(cause);
	}

}
