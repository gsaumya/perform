package com.cts.bankmanagement.service;

import java.text.MessageFormat;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cts.bankmanagement.dao.PerformTransactionDao;
import com.cts.bankmanagement.dao.UserDAO;
import com.cts.bankmanagement.exception.BankManagementException;
import com.cts.bankmanagement.vo.TransactionVO;
import com.cts.bankmanagement.vo.UserVO;

@Service("transactionService")
public class PerformTransactionServiceImpl implements PerformTransactionService {

	@Autowired
	private UserDAO userDao;
	private static final Logger LOG = Logger.getLogger(PerformTransactionServiceImpl.class);
	private final static String DEPOSIT = "deposit";
	private final static String WITHDRAWAL = "withdrawal";
	private final static String SAVINGS = "savings";
	private final static String BALANCE_ERROR_KEY = "balanceError";
	private final static String ACCOUNT_ERROR_KEY = "accountError";
	private final static Long TRANSACTION_ID_SEED_VALUE = 1000000000L;

	@Autowired
	PerformTransactionDao transactionDao;

	@Transactional
	@Override
	public Double updateTransactionDetail(TransactionVO transactionVO) throws BankManagementException {

		LOG.info(" In PerformTransactionServiceImpl class which implements PerformTransactionService");

		UserVO userVO = userDao.getUserDetails(transactionVO.getAccountNumber());
		if (userVO == null) {
			LOG.error("Account number is invalid");
			throw new BankManagementException(ACCOUNT_ERROR_KEY,
					MessageFormat.format("Invalid Account No", transactionVO.getAccountNumber()));
		}

		Double accountBalance = userVO.getAccountBalance() == null ? 0 : userVO.getAccountBalance();
		Double transaction_amount = transactionVO.getTransactionAmount();
		if (DEPOSIT.equalsIgnoreCase(transactionVO.getTransactionType())) {
			accountBalance += transaction_amount;
			userVO.setAccountBalance(accountBalance);
			userDao.updateUserDetails(userVO);
		}

		if (WITHDRAWAL.equalsIgnoreCase(transactionVO.getTransactionType())) {

			String accountType = userVO.getAccountType();
			if (transactionVO.getTransactionAmount() > accountBalance) {
				LOG.error("Insufficient balance");
				throw new BankManagementException(BALANCE_ERROR_KEY,
						MessageFormat.format("Insufficient balance {0}", userVO.getAccountBalance()));

			} else if (SAVINGS.equalsIgnoreCase(accountType)) {
				if ((userVO.getAccountBalance() - transaction_amount) < 5000) {
					LOG.error("Saving amount should not be less than 5000");
					throw new BankManagementException(BALANCE_ERROR_KEY,
							MessageFormat.format("Savings amount balance can't be less than 5000", 5000));
				}
			}

			accountBalance -= transaction_amount;
			userVO.setAccountBalance(accountBalance);
			userDao.updateUserDetails(userVO);
		}

		setTransactionId(transactionVO);
		transactionDao.updateTransactionDetail(transactionVO);
		return accountBalance;

	}

	private void setTransactionId(TransactionVO transactionVO) {
		Long count = transactionDao.countTransactionDetail();
		transactionVO.setTransactionId(TRANSACTION_ID_SEED_VALUE + count);

	}
}