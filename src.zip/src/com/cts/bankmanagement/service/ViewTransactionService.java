package com.cts.bankmanagement.service;

import java.util.List;

import com.cts.bankmanagement.vo.TransactionVO;

public interface ViewTransactionService {

	List<TransactionVO> retreiveTransactionService(Long accountNumber, Long transactionId);

	//List<TransactionVo> getTransactionsVo(Long accountNumber, Long transactionId);

	
}
