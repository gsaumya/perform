package com.cts.bankmanagement.vo;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

public class TransactionVO {

	@Range(min = 1000000000000000L, max = 9999999999999999L, message = "Account number should have 16 digits")
	@NotNull(message = "Account number does not exist")
	private Long accountNumber;

	private Long transactionId;

	@NotBlank(message = "Transaction type can't be empty")
	private String transactionType;

	@Range(min = 1, message = "Transaction amount can't be less than 1")
	@NotNull(message = "Transaction amount can't be empty")
	private Double transactionAmount;

	@NotNull(message = "Description can't be empty")
	@NotEmpty(message = "Description can't be empty")
	private String description;

	private UserVO userVO;

	public TransactionVO(Long accountNumber, String transactionType, Double transactionAmount, String description) {

		super();
		this.userVO = new UserVO(accountNumber);
		this.transactionAmount = transactionAmount;
		this.transactionType = transactionType;
		this.accountNumber = accountNumber;
		this.description = description;
	}

	

	public TransactionVO(Long transactionId, UserVO userVO, Double transactionAmount, String transactionType,
			String description) {
		super();
	    this.accountNumber = userVO.getAccountNumber();
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.transactionAmount = transactionAmount;
		this.description = description;
		this.userVO = new UserVO(userVO.getAccountNumber(), userVO.getAccountType(), userVO.getAccountHolderName(),
				userVO.getAccountBalance());
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public  Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Double getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(Double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public UserVO getUserVO() {
		return userVO;
	}

	public void setUserVo(UserVO userVO) {
		this.userVO = userVO;
	}
}
