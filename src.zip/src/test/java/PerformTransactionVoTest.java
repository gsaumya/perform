package test.java;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.cts.bankmanagement.dao.UserDAO;
import com.cts.bankmanagement.exception.BankManagementException;
import com.cts.bankmanagement.service.PerformTransactionService;
import com.cts.bankmanagement.vo.TransactionVO;
import com.cts.bankmanagement.vo.UserVO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:bms-test-context.xml" })
public class PerformTransactionVoTest {

	@Autowired
	private PerformTransactionService transactionService;

	@Autowired
	private UserDAO userDao;

	@Rollback(true)
	@Transactional
	@Test(expected = BankManagementException.class)
	public void testWithdrawalWhenReceivedBalanceIsMore() throws BankManagementException {
		assertThat(transactionService, instanceOf(PerformTransactionService.class));
		UserVO userVO = userDao.getUserDetails(2345678909876543L);
		Double accountBalance = userVO.getAccountBalance();
		Double balance = 15000d;
		TransactionVO transactionVo = new TransactionVO(2345678909876543L, "withdrawal", balance, "test");
		Double receivedBalance = transactionService.updateTransactionDetail(transactionVo);
		assertThat(receivedBalance, is(accountBalance - receivedBalance));
	}

	@Rollback(true)
	@Transactional
	@Test
	public void testDeposit() throws BankManagementException {
		assertThat(transactionService, instanceOf(PerformTransactionService.class));
		TransactionVO transactionVo = new TransactionVO(4410987654234567L, "deposit", 2000D, "test");
		transactionService.updateTransactionDetail(transactionVo);
	}

	@Rollback(true)
	@Transactional
	@Test(expected = BankManagementException.class)
	public void testUpdateTransactionDetailsForWithdrawalForInvalidTransactionAmountFromSavings()
			throws BankManagementException {
		UserVO userVO = userDao.getUserDetails(4410987654234567L);
		Double accountBalance = userVO.getAccountBalance();
		Double transactionAmount = 8000d;
		TransactionVO transactionVo = new TransactionVO(4410987654234567L, "withdrawal", transactionAmount, "test");
		Double receivedBalance = transactionService.updateTransactionDetail(transactionVo);
		assertThat(receivedBalance, is(accountBalance - transactionAmount));
	}

}